Created by matthewjearly@gmail.com under appropriate licenses and laws (open source, fair use, and creative commons I think)

To Use this program -

	1. Unzip to desired location.

	2. Run the 'ARK-Survial-Evolved-damage-calculator.exe' application to start the program. 

	3. Okay through your security prompts(I know I'm not a verified developer but can ensure you the code is clean - check it out @ https://github.com/bytePro17124/ARK-Survial-Evolved-damage-calculator or have a knowledgable friend do so). 

	4. This main '.exe' application file must stay in the folder with the .dll's and other folders.  

	5. (optional or done before step 2 if you want) Make shortcuts or pin it to your start menu.

Additonal Information -

Email: matthewjearly@gmail.com with the topic ARK Damage Calculator with questions, comments, bugs, or anything.

Support: This program is entirely free. If you want to donate to support me as a general developer - my Paypal is the same email address ( matthewjearly@gmail.com ). I appreciate any support I can get but do not rely on donations currently.